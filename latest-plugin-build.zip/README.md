# Framer Grid Pattern Plugin

Create beautiful grid patterns with customizable properties for your Framer designs.

## Features

- Generate various grid patterns in real-time
- Customize colors, sizes, and spacing
- Apply to any frame in your Framer project
- Easy to use interface with live preview

## Usage

1. Select a frame in your Framer project
2. Open the Grid Pattern plugin from the plugin menu
3. Customize your grid pattern settings
4. Apply the pattern to your selected frame

## Support

For support or feature requests, please contact:
- Email: madhoundes@gmail.com
- Twitter: [@ahmed-almadhoun](https://twitter.com/ahmed-almadhoun)

## License

This plugin is licensed under the MIT License. 